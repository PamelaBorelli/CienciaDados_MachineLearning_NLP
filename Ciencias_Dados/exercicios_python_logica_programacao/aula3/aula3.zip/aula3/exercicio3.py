'''
Desenvolver um algoritmo e efetuar a implementação em Python, para ler um número e 
informar se é par ou impar.

'''


#entrada de dados
num = int(input('Digite um número: '))


#processamento e dados de saída
if(num % 2 == 0):
    print("o número é par")
else:
    print("o número é ímpar")